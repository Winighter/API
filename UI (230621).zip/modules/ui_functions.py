from main import *

class UIFunctions(MainWindow):
    def uiDefinitions(self):
        self.setWindowFlags(Qt.FramelessWindowHint)

        def moveWindow(event):
            if event.buttons() == Qt.LeftButton:
                self.move(self.pos() + event.globalPos() - self.dragPos)
                self.dragPos = event.globalPos()
                # event.accept()
        self.ui.bgApp.mouseMoveEvent = moveWindow
        
        # MINIMIZE
        self.ui.Btn_Minimize.clicked.connect(lambda: self.showMinimized())

        # CLOSE APPLICATION
        self.ui.Btn_Close.clicked.connect(lambda: self.close())