class Test:
    def __init__(self):
        pass

    


if __name__ == '__main__':
    Test()