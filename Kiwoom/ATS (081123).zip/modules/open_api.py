from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QAxContainer import *
from PyQt5.QtCore import *
from PyQt5.QtMultimedia import *
from PyQt5.QtMultimediaWidgets import *

from modules import *

class Kiwoom(QAxWidget):
    def onLogin(self):
        Kiwoom.login_event_loop = QEventLoop()
        self.kiwoom = QAxWidget("KHOPENAPI.KHOpenAPICtrl.1")
        Kiwoom.onEvent(self)
        self.kiwoom.dynamicCall("CommConnect()")
        AppFunctions.loginState(self,2)
        Kiwoom.login_event_loop.exec_()

    def onEvent(self):
        self.kiwoom.OnEventConnect.connect(self.login_slot)
        self.kiwoom.OnReceiveTrData.connect(self.trdata_slot)
        self.kiwoom.OnReceiveChejanData.connect(self.chejan_slot)
        self.kiwoom.OnReceiveRealData.connect(self.realdata_slot)

    def connect_real_data(self):
        Kiwoom.Disconnect_All_Real(self)
        Kiwoom.regist_Real_Code(self,'3691',S.fCode,'128','0')
        Kiwoom.regist_Real_Code(self,'2000',self.cStr,'10;16;17;18','1')
        Kiwoom.regist_Real_Code(self,'2001',self.pStr,'10;16;17;18','1')


    def Disconnect_All_Real(self):
        if S.LOGIN_STATE == 1:
            self.kiwoom.dynamicCall("SetRealRemove(QString,QString)",'ALL','ALL')

    def regist_Real_Code(self,strScreenNo,CodeList,FidList,OptType):
        self.kiwoom.dynamicCall("SetRealReg(QString,QString,QString,QString)",strScreenNo,CodeList,FidList,OptType)

    def request_login_info(self):
        self.account = self.kiwoom.dynamicCall("GetLoginInfo(QString)","ACCOUNT_CNT")
        self.Number = self.kiwoom.dynamicCall("GetLoginInfo(QString)","ACCLIST")[:-1] # or "ACCNO" / 계좌번호
        fList = self.kiwoom.dynamicCall("GetFutureList()").split(';')
        S.fCode = fList[0]

        oMonth = list(map(int, self.kiwoom.dynamicCall("GetMonthList()").split(';')))
        oMonth.sort()
        self.oMonth = str(oMonth[0])


    # Post here your functions for Tr Data
    # ///////////////////////////////////////////////////////////////
    def request_balance(self):
        self.kiwoom.dynamicCall("SetInputValue(QString,QString)","계좌번호",self.Number)
        self.kiwoom.dynamicCall("SetInputValue(QString,QString)","비밀번호",'')
        self.kiwoom.dynamicCall("SetInputValue(QString,QString)","비밀번호입력매체구분",'00')
        self.kiwoom.dynamicCall("CommRqData(QString,QString,QString,QString)","선옵잔고","opw20007","0", '1001')
        self.tr_event_loop.exec_()

    def request_option_price(self):
        self.kiwoom.dynamicCall("SetInputValue(QString,QString)","만기년월",self.oMonth)
        self.kiwoom.dynamicCall("CommRqData(QString,QString,QString,QString)","옵션시세","opt50020","0", '1003')
        self.tr_event_loop.exec_()

    # ORDER FUNTION & ORDER RESULTS
    def request_orderFO(self,sRQName,sCode,lQty,sPrice,why,OrdNo):
        global order_err
        if sRQName == '신규매수':
            order_err = self.kiwoom.dynamicCall("SendOrderFO(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)",[
                sRQName,'1000',self.Number,sCode,'1','2','1',S.수량,sPrice,''])

        if sRQName == '신규매도':
            order_err = self.kiwoom.dynamicCall("SendOrderFO(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)",[
                sRQName,'1000',self.Number,sCode,'1','1','3',lQty,'3',''])

        if sRQName == '정정':
            order_err = self.kiwoom.dynamicCall("SendOrderFO(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)",[
                sRQName,'1000',self.Number,sCode,'2','2','1',lQty,sPrice,OrdNo])

        if order_err == 0:
            if sRQName == '신규매도':
                S.매수 = False
                S.correction_order_dict = {}

            if why == '잔고매도':
                S.매수 = False
                S.balance_dict = {}

            if why == '이익':
                S.profit_code = str(sCode[0:1])
                S.balance_dict = {}
                if S.profit_code != '':
                    self.ORDER = False

            if sRQName == '정정':
                S.정정 = False

            if sRQName == '본전':
                S.손절10 = False
                S.balance_dict = {}