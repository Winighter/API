# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainpsBPqw.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_LoginScreen(object):
    def setupUi(self, LoginScreen):
        if not LoginScreen.objectName():
            LoginScreen.setObjectName(u"LoginScreen")
        LoginScreen.resize(270, 380)
        LoginScreen.setMinimumSize(QSize(270, 380))
        LoginScreen.setMaximumSize(QSize(270, 380))
        self.bgApp = QWidget(LoginScreen)
        self.bgApp.setObjectName(u"bgApp")
        self.bgApp.setMinimumSize(QSize(0, 0))
        self.bgApp.setMaximumSize(QSize(16777215, 16777215))
        self.bgApp.setStyleSheet(u"/*QWidget*/\n"
"QWidget {\n"
"background-color: #EB8F90;\n"
"}\n"
"/*Top Bar//////////////////////////////////////////////////////*/\n"
"/*Left Top Bar*/\n"
"#label_description{color: #FFFFFF;}\n"
"\n"
"/*Rigth Top Bar*/\n"
"#RightTopBar .QPushButton{color: #FFFFFF;border: none;}\n"
"#RightTopBar .QPushButton:hover {background-color:#FFB471;}\n"
"#RightTopBar .QPushButton:pressed{background-color: #ADBED2;}\n"
"\n"
"/*Main////////////////////////////////////////////////////////*/\n"
"/*Login Page*/\n"
"#label_LoginState{color: #E81E25;}\n"
"#label_Login {color:#FFFFFF;}\n"
"#frame .QLineEdit{color:#FFFFFF;}\n"
"#frame_6 .QPushButton{color:#FFFFFF;}\n"
"#Btn_Login {\n"
"color:#FFFFFF;\n"
"background-color: #FFB471;\n"
"border: 0px solid;\n"
"border-radius:20px;\n"
"}\n"
"\n"
"\n"
"/*Bottom Bar////////////////////////////////////////*/\n"
"/*Left Bottom*/\n"
"#LoginStateLabel {padding-left:5px;}\n"
"/*Right Bottom*/\n"
"#label_version{color:#FFFFFF;padding-right:5px;}\n"
"\n"
"")
        self.verticalLayout = QVBoxLayout(self.bgApp)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.TopBar = QFrame(self.bgApp)
        self.TopBar.setObjectName(u"TopBar")
        self.TopBar.setMinimumSize(QSize(0, 30))
        self.TopBar.setMaximumSize(QSize(16777215, 30))
        self.TopBar.setStyleSheet(u"")
        self.TopBar.setFrameShape(QFrame.NoFrame)
        self.TopBar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout = QHBoxLayout(self.TopBar)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.LeftTopBar = QFrame(self.TopBar)
        self.LeftTopBar.setObjectName(u"LeftTopBar")
        self.LeftTopBar.setStyleSheet(u"")
        self.LeftTopBar.setFrameShape(QFrame.NoFrame)
        self.LeftTopBar.setFrameShadow(QFrame.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.LeftTopBar)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(10, 0, 0, 0)
        self.label_description = QLabel(self.LeftTopBar)
        self.label_description.setObjectName(u"label_description")
        font = QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_description.setFont(font)

        self.verticalLayout_7.addWidget(self.label_description)


        self.horizontalLayout.addWidget(self.LeftTopBar)

        self.RightTopBar = QFrame(self.TopBar)
        self.RightTopBar.setObjectName(u"RightTopBar")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.RightTopBar.sizePolicy().hasHeightForWidth())
        self.RightTopBar.setSizePolicy(sizePolicy)
        self.RightTopBar.setMaximumSize(QSize(80, 16777215))
        self.RightTopBar.setStyleSheet(u"")
        self.RightTopBar.setFrameShape(QFrame.NoFrame)
        self.RightTopBar.setFrameShadow(QFrame.Raised)
        self.RightTopBar.setLineWidth(1)
        self.horizontalLayout_2 = QHBoxLayout(self.RightTopBar)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.Btn_Minimize = QPushButton(self.RightTopBar)
        self.Btn_Minimize.setObjectName(u"Btn_Minimize")
        sizePolicy.setHeightForWidth(self.Btn_Minimize.sizePolicy().hasHeightForWidth())
        self.Btn_Minimize.setSizePolicy(sizePolicy)
        self.Btn_Minimize.setMinimumSize(QSize(40, 0))
        self.Btn_Minimize.setFont(font)
        self.Btn_Minimize.setStyleSheet(u"")

        self.horizontalLayout_2.addWidget(self.Btn_Minimize)

        self.Btn_Close = QPushButton(self.RightTopBar)
        self.Btn_Close.setObjectName(u"Btn_Close")
        sizePolicy.setHeightForWidth(self.Btn_Close.sizePolicy().hasHeightForWidth())
        self.Btn_Close.setSizePolicy(sizePolicy)
        self.Btn_Close.setMinimumSize(QSize(40, 0))
        self.Btn_Close.setFont(font)
        self.Btn_Close.setStyleSheet(u"#RightTopBar .QPushButton:hover {background-color:#E81E25;}")

        self.horizontalLayout_2.addWidget(self.Btn_Close)


        self.horizontalLayout.addWidget(self.RightTopBar)


        self.verticalLayout.addWidget(self.TopBar)

        self.stackedWidget = QStackedWidget(self.bgApp)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.page_login = QWidget()
        self.page_login.setObjectName(u"page_login")
        self.verticalLayout_3 = QVBoxLayout(self.page_login)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.frame = QFrame(self.page_login)
        self.frame.setObjectName(u"frame")
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy1)
        self.frame.setStyleSheet(u"")
        self.frame.setInputMethodHints(Qt.ImhHiddenText)
        self.frame.setFrameShape(QFrame.NoFrame)
        self.frame.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame)
        self.verticalLayout_2.setSpacing(10)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(30, 30, 30, 20)
        self.label_LoginState = QLabel(self.frame)
        self.label_LoginState.setObjectName(u"label_LoginState")
        self.label_LoginState.setMaximumSize(QSize(16777215, 30))
        self.label_LoginState.setFont(font)
        self.label_LoginState.setStyleSheet(u"")
        self.label_LoginState.setAlignment(Qt.AlignCenter)

        self.verticalLayout_2.addWidget(self.label_LoginState)

        self.label_Login = QLabel(self.frame)
        self.label_Login.setObjectName(u"label_Login")
        self.label_Login.setMaximumSize(QSize(16777215, 45))
        font1 = QFont()
        font1.setPointSize(30)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_Login.setFont(font1)
        self.label_Login.setAlignment(Qt.AlignCenter)

        self.verticalLayout_2.addWidget(self.label_Login, 0, Qt.AlignVCenter)

        self.frame_2 = QFrame(self.frame)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setMaximumSize(QSize(16777215, 0))
        self.frame_2.setFrameShape(QFrame.NoFrame)
        self.frame_2.setFrameShadow(QFrame.Raised)

        self.verticalLayout_2.addWidget(self.frame_2)

        self.LineEdit_ID = QLineEdit(self.frame)
        self.LineEdit_ID.setObjectName(u"LineEdit_ID")
        sizePolicy2 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.LineEdit_ID.sizePolicy().hasHeightForWidth())
        self.LineEdit_ID.setSizePolicy(sizePolicy2)
        self.LineEdit_ID.setMinimumSize(QSize(0, 20))
        self.LineEdit_ID.setMaximumSize(QSize(16777215, 16777215))
        self.LineEdit_ID.setFont(font)
        self.LineEdit_ID.setStyleSheet(u"background-color:rgba(0, 0, 0, 0);\n"
"border:none;\n"
"border-bottom:2px solid #FFFFFF;\n"
"padding-bottom:7px;")
        self.LineEdit_ID.setInputMethodHints(Qt.ImhNone)

        self.verticalLayout_2.addWidget(self.LineEdit_ID)

        self.LineEdit_PW = QLineEdit(self.frame)
        self.LineEdit_PW.setObjectName(u"LineEdit_PW")
        self.LineEdit_PW.setMinimumSize(QSize(0, 20))
        self.LineEdit_PW.setMaximumSize(QSize(16777215, 16777215))
        self.LineEdit_PW.setFont(font)
        self.LineEdit_PW.setStyleSheet(u"background-color:rgba(0, 0, 0, 0);\n"
"border:none;\n"
"border-bottom:2px solid #FFFFFF;\n"
"padding-bottom:7px;")
        self.LineEdit_PW.setInputMethodHints(Qt.ImhHiddenText|Qt.ImhNoAutoUppercase|Qt.ImhNoPredictiveText|Qt.ImhSensitiveData)
        self.LineEdit_PW.setEchoMode(QLineEdit.Password)
        self.LineEdit_PW.setClearButtonEnabled(True)

        self.verticalLayout_2.addWidget(self.LineEdit_PW)

        self.frame_11 = QFrame(self.frame)
        self.frame_11.setObjectName(u"frame_11")
        self.frame_11.setMinimumSize(QSize(0, 0))
        self.frame_11.setMaximumSize(QSize(16777215, 15))
        self.frame_11.setFrameShape(QFrame.NoFrame)
        self.frame_11.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_7 = QHBoxLayout(self.frame_11)
        self.horizontalLayout_7.setSpacing(5)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.checkBox_All = QCheckBox(self.frame_11)
        self.checkBox_All.setObjectName(u"checkBox_All")
        self.checkBox_All.setMinimumSize(QSize(0, 0))
        self.checkBox_All.setMaximumSize(QSize(16777215, 16777215))
        font2 = QFont()
        font2.setPointSize(9)
        font2.setBold(True)
        font2.setWeight(75)
        self.checkBox_All.setFont(font2)
        self.checkBox_All.setStyleSheet(u"color: rgb(255, 255, 255);")

        self.horizontalLayout_7.addWidget(self.checkBox_All)

        self.checkBox_Order = QCheckBox(self.frame_11)
        self.checkBox_Order.setObjectName(u"checkBox_Order")
        self.checkBox_Order.setMinimumSize(QSize(0, 0))
        self.checkBox_Order.setMaximumSize(QSize(60, 15))
        self.checkBox_Order.setFont(font2)
        self.checkBox_Order.setStyleSheet(u"color: rgb(255, 255, 255);")

        self.horizontalLayout_7.addWidget(self.checkBox_Order)


        self.verticalLayout_2.addWidget(self.frame_11, 0, Qt.AlignRight)

        self.Btn_Login = QPushButton(self.frame)
        self.Btn_Login.setObjectName(u"Btn_Login")
        self.Btn_Login.setEnabled(True)
        sizePolicy3 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.Btn_Login.sizePolicy().hasHeightForWidth())
        self.Btn_Login.setSizePolicy(sizePolicy3)
        self.Btn_Login.setMinimumSize(QSize(0, 40))
        self.Btn_Login.setFont(font)
        self.Btn_Login.setStyleSheet(u"QPushButton:hover {background-color: #FFA289}")

        self.verticalLayout_2.addWidget(self.Btn_Login)


        self.verticalLayout_3.addWidget(self.frame)

        self.stackedWidget.addWidget(self.page_login)
        self.page_main = QWidget()
        self.page_main.setObjectName(u"page_main")
        self.page_main.setStyleSheet(u"background-color: #FFB471;")
        self.verticalLayout_8 = QVBoxLayout(self.page_main)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.frame_7 = QFrame(self.page_main)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setFrameShape(QFrame.NoFrame)
        self.frame_7.setFrameShadow(QFrame.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.frame_7)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.label_FutureHoka = QLabel(self.frame_7)
        self.label_FutureHoka.setObjectName(u"label_FutureHoka")
        self.label_FutureHoka.setFont(font1)
        self.label_FutureHoka.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label_FutureHoka.setAlignment(Qt.AlignCenter)

        self.verticalLayout_4.addWidget(self.label_FutureHoka)


        self.verticalLayout_8.addWidget(self.frame_7)

        self.stackedWidget.addWidget(self.page_main)

        self.verticalLayout.addWidget(self.stackedWidget)

        self.BottomBar = QFrame(self.bgApp)
        self.BottomBar.setObjectName(u"BottomBar")
        self.BottomBar.setMinimumSize(QSize(0, 30))
        self.BottomBar.setMaximumSize(QSize(16777215, 30))
        self.BottomBar.setFrameShape(QFrame.NoFrame)
        self.BottomBar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.BottomBar)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.LoginStateLabel = QLabel(self.BottomBar)
        self.LoginStateLabel.setObjectName(u"LoginStateLabel")
        self.LoginStateLabel.setFont(font)
        self.LoginStateLabel.setStyleSheet(u"color: #E81E25;")
        self.LoginStateLabel.setMargin(5)

        self.horizontalLayout_4.addWidget(self.LoginStateLabel)

        self.label_version = QLabel(self.BottomBar)
        self.label_version.setObjectName(u"label_version")
        self.label_version.setFont(font)
        self.label_version.setStyleSheet(u"")
        self.label_version.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.label_version.setMargin(5)

        self.horizontalLayout_4.addWidget(self.label_version)


        self.verticalLayout.addWidget(self.BottomBar)

        LoginScreen.setCentralWidget(self.bgApp)

        self.retranslateUi(LoginScreen)

        self.stackedWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(LoginScreen)
    # setupUi

    def retranslateUi(self, LoginScreen):
        LoginScreen.setWindowTitle(QCoreApplication.translate("LoginScreen", u"MainWindow", None))
        self.label_description.setText(QCoreApplication.translate("LoginScreen", u"Auto Trading System", None))
        self.Btn_Minimize.setText(QCoreApplication.translate("LoginScreen", u"__", None))
        self.Btn_Close.setText(QCoreApplication.translate("LoginScreen", u"X", None))
        self.label_LoginState.setText("")
        self.label_Login.setText(QCoreApplication.translate("LoginScreen", u"Login", None))
        self.LineEdit_ID.setPlaceholderText(QCoreApplication.translate("LoginScreen", u"USERNAME", None))
        self.LineEdit_PW.setPlaceholderText(QCoreApplication.translate("LoginScreen", u"PASSWORD", None))
        self.checkBox_All.setText(QCoreApplication.translate("LoginScreen", u"All", None))
        self.checkBox_Order.setText(QCoreApplication.translate("LoginScreen", u"Order", None))
        self.Btn_Login.setText(QCoreApplication.translate("LoginScreen", u"LOGIN", None))
        self.label_FutureHoka.setText(QCoreApplication.translate("LoginScreen", u"0", None))
        self.LoginStateLabel.setText(QCoreApplication.translate("LoginScreen", u"Unconnected", None))
        self.label_version.setText(QCoreApplication.translate("LoginScreen", u"1.0.0", None))
    # retranslateUi

