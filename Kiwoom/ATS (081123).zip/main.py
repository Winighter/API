import sys,time
from modules import *
from widgets import *
from PySide2.QtGui import *
from PySide2.QtCore import *
from PySide2.QtWidgets import *

추세 = ''
class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_LoginScreen()
        self.ui.setupUi(self)
        self.setWindowTitle('ATS')
        UIFunctions.uiDefinitions(self)
        self.ui.Btn_Login.clicked.connect(self.onLogin)
        self.show()
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_login)

    def onLogin(self):
        self.ORDER = False
        btn = self.sender()
        btnName = btn.objectName()
        self.ORDER = self.ui.checkBox_Order.isChecked()
        self.all_option_state = self.ui.checkBox_All.isChecked()

        if btnName == "Btn_Login":
            #if self.ui.LineEdit_ID.text() == '' and self.ui.LineEdit_PW.text() == '':
                self.tr_event_loop = QEventLoop()
                self.ui.stackedWidget.setCurrentWidget(self.ui.page_main)
                Kiwoom.onLogin(self)

    def mousePressEvent(self, event):
        self.dragPos = event.globalPos()

    # KIWOOM TERRITORY
    def login_slot(self, err_code): # LOGIN EVENT
        if err_code != (0 and 1):
            print(errors(err_code)[1])
        else:
            Kiwoom.login_event_loop.exit()
            AppFunctions.loginState(self,0)
            Kiwoom.request_login_info(self)
            if self.all_option_state:
                Kiwoom.request_balance(self)
            Kiwoom.request_option_price(self)
            Kiwoom.connect_real_data(self)

    # TR EVENT TERRITORY
    def trdata_slot(self, sScrNo, sRQName, sTrCode, sRecordName):
        if sRQName == "선옵잔고":
            rows = self.kiwoom.dynamicCall("GetRepeatCnt(QString, QString)", sTrCode, sRQName)
            if rows > 0:
                for i in range(rows):
                    Code = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"종목코드")
                    Code = Code.strip()

                    Gubun = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"매도매수구분")
                    Gubun = Gubun.strip()
                    if Gubun == "2":
                        Gubun = "매수"
                    else:
                        Gubun = "매도"

                    Quantity = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"수량")
                    Quantity = int(Quantity.strip())

                    Buy_Price = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"매입단가")
                    Buy_Price = float(Buy_Price.strip()) * 0.001

                    Price = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"현재가")
                    Price = float(Price.strip()) * 0.001

                    청산가능수량 = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"청산가능수량")
                    청산가능수량 = int(청산가능수량.strip())

                    약정금액 = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"약정금액")
                    약정금액 = int(약정금액.strip())

                    평가금액 = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"평가금액")
                    평가금액 = int(평가금액.strip())

                    수익률 = round(((평가금액 - 약정금액) / 약정금액 * 100), 2)

                    S.balance_dict = {"종목코드": Code,"구분": Gubun,"수량": Quantity,"매입단가": Buy_Price,"현재가": Price,"청산가능수량": 청산가능수량,"약정금액": 약정금액,"평가금액": 평가금액,"수익률": 수익률}
                    Kiwoom.regist_Real_Code(self,'2000',Code,'10;16;17;18','1')

                    if (S.손절 >= 수익률) or (수익률 >= S.이익):
                        print("잔고 매도 시작")
                        Kiwoom.request_orderFO(self, "신규매도", Code, 청산가능수량, "0",'잔고매도','')

            Kiwoom.Disconnect_All_Real(self)
            self.tr_event_loop.exit()

        if sRQName == "옵션시세":
            oAct = []
            oCode = []
            cStr = []
            pStr = []
            rows = self.kiwoom.dynamicCall("GetRepeatCnt(QString, QString)", sTrCode, sRQName)
            for i in range(rows):
                cCode = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"종목코드")
                cCode = cCode.strip()

                cPrice = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"현재가")
                cPrice = float(cPrice.strip().lstrip("+").lstrip("-"))

                pCode = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_종목코드")
                pCode = pCode.strip()

                pPrice = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_현재가")
                pPrice = float(pPrice.strip().lstrip("+").lstrip("-"))

                if (S.buy_min_price <= cPrice <= S.buy_max_price):
                    cStr.append(cCode)
                    oCode.append(cCode)
                if (S.buy_min_price <= pPrice <= S.buy_max_price):
                    pStr.append(pCode)
                    oCode.append(pCode)

                oAct = list(set(oAct))
                oAct.sort()
                i = len(oAct) + 2
                Kiwoom.Disconnect_All_Real(self)

            cStr.sort(reverse=True)
            pStr.sort(reverse=True)
            oCode.sort(reverse=True)
            self.cStr = ";".join(cStr)
            self.pStr = ";".join(pStr)
            self.oCode = oCode
            self.tr_event_loop.exit()

    def chejan_slot(self, Gubun, nItemCnt, sFidList):
        if int(Gubun) == 0:
            oCode = self.kiwoom.dynamicCall("GetChejanData(int)", 9001)  # 종목코드

            medosu = self.kiwoom.dynamicCall("GetChejanData(int)", 905)  # 구분
            medosu = medosu.strip().lstrip("+").lstrip("-")

            order_number = self.kiwoom.dynamicCall("GetChejanData(int)", 9203)  # 주문번호
            on = int(order_number)

            order_q = self.kiwoom.dynamicCall("GetChejanData(int)", 900)  # 주문수량
            order_q = int(order_q)

            un_quan = self.kiwoom.dynamicCall("GetChejanData(int)", 902)  # 미체결수량
            un_quan = int(un_quan)

            one_order_number = self.kiwoom.dynamicCall("GetChejanData(int)", 904)  # 원주문번호
            oon = int(one_order_number)

            order_price = self.kiwoom.dynamicCall("GetChejanData(int)", 901)  # 주문가격
            order_price = float(order_price)

            print(medosu,order_q,un_quan,order_price)

            if (un_quan == 0) and ("취소" not in medosu):
                if medosu == "매수":
                    S.balance_dict.update({"종목코드": oCode,"구분": medosu,"수량": order_q,"매입단가": order_price,"청산가능수량": order_q})

                if medosu == '매도':
                    S.balance_dict = {}
            else:
                if medosu != '매수정정':
                    S.correction_order_dict.update({"종목코드": oCode,"구분": medosu,"주문번호": on,"주문수량": order_q,"주문가격": order_price,"미체결수량": un_quan,"원주문번호": oon})


    def realdata_slot(self, oCode, RealType):
        global 추세

        if RealType == "선물호가잔량":
            a = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 128)  # 순매수잔량
            a = int(a)
            S.HOKA = a
            self.ui.label_FutureHoka.setText(str(format(a,',')))

            if 4000 <= a:
                추세 = 'CALL'
                self.ui.label_FutureHoka.setStyleSheet('color: #E81E25')

            elif -4000 >= a:
                추세 = 'PUT'
                self.ui.label_FutureHoka.setStyleSheet('color: #0359AE')

            else:
                추세 = ''
                self.ui.label_FutureHoka.setStyleSheet('color: #FFFFFF')

        elif RealType == "옵션시세":
            a = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 10)  # 현재가
            a = abs(float(a))

            b = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 16)  # 시가
            b = abs(float(b))

            c = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 28)  # (최우선)매수호가
            c = abs(float(c))

            if self.ORDER:
                # BUY ORDER TERRITORY
                if (S.balance_dict == {}) and (S.매수 == False) and (S.buy_min_price <= a <= S.buy_max_price) and (a >= (b + 0.05)):
                    if (S.profit_code == '') and (((oCode[0:1] == "2") and (추세 == "CALL")) or ((oCode[0:1] == "3") and (추세 == "PUT"))):
                        S.매수 = True
                        Kiwoom.request_orderFO(self, "신규매수", oCode, S.수량, a, '','')

                    elif (S.profit_code == '3') and (oCode[0:1] == "2") and (추세 == "CALL"):
                        S.매수 = True
                        Kiwoom.request_orderFO(self, "신규매수", oCode, S.수량, a, '','')

                    elif (S.profit_code == '2') and (oCode[0:1] == "3") and (추세 == "PUT"):
                        S.매수 = True
                        Kiwoom.request_orderFO(self, "신규매수", oCode, S.수량, a, '','')

                # SELL ORDER TERRITORY
                if S.balance_dict != {}:
                    if (S.매수 == True) and (oCode == S.balance_dict["종목코드"]):
                        buy_price = float(S.balance_dict["매입단가"])
                        주문가능수량 = int(S.balance_dict["청산가능수량"])
                        수익률 = self.calculating_the_return(price=c,quantity=주문가능수량,bp=buy_price)
                        print(수익률,S.손절10,S.HOKA)
                        if (S.손절10 == False) and (수익률 >= 10):
                            S.손절10 = True

                        # 공통 손절 매도 주문
                        if 수익률 <= S.손절:
                            S.매수 = False
                            print("손절 매도")
                            S.손절Cnt += 1
                            S.balance_dict = {}
                            if S.손절Cnt >= 2:
                                print("손절2번")
                                self.ORDER = False
                            Kiwoom.request_orderFO(self,"신규매도", oCode, 주문가능수량, "0",'손절','')

                        # 공통 이익 매도 주문
                        if 수익률 >= S.이익:
                            S.매수 = False
                            print("이익 매도 시작")
                            Kiwoom.request_orderFO(self, "신규매도", oCode, 주문가능수량, "0", '이익','')

                        if (S.손절10 == True) and (수익률 <= 3):
                            print("본전 매도 시작")
                            Kiwoom.request_orderFO(self, "신규매도", oCode, 주문가능수량, "0", '본전','')

                # CORRECTION ORDER TERRITORY
                if S.correction_order_dict != {}:
                    cod = S.correction_order_dict
                    종목코드 = cod['종목코드']
                    미체결수량 = cod['미체결수량']
                    주문가격 = cod['주문가격']
                    가격차이 = round(a - 주문가격,3)
                    if (S.정정 == False) and (oCode == 종목코드) and (미체결수량 > 0) and (c > 가격차이):
                        S.정정 = True
                        주문번호 = cod['주문번호']
                        Kiwoom.request_orderFO(self,'정정',종목코드,미체결수량,a,'',주문번호)

    def calculating_the_return(self, price, quantity, bp):
        총평가금액 = price * quantity * 250000
        총매입금액 = bp * quantity * 250000
        result = (총평가금액 - 총매입금액) / 총매입금액 * 100
        results = round(result,2)
        return results

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    main = MainWindow()
    sys.exit(app.exec_())