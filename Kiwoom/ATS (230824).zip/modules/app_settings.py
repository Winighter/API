class S(): # S = Settings
    # APP SETTINGS
    # ///////////////////////////////////////////////////////////////
    LOGIN_STATE = 0
    ORDER = False
    fCode = ''
    HOKA = 0

    # DICTIONARY
    # ///////////////////////////////////////////////////////////////
    correction_order_dict = {}
    option_table_dict = {}
    balance_dict = {}
    # CONDITION
    # ///////////////////////////////////////////////////////////////
    Act_Check = 0
    매수 = False
    정정 = False
    손절Cnt = 0
    손절10 = False
    손절 = -8
    이익 = 30
    수량 = 8
    profit_code = ''
    buy_min_price = 0.5
    buy_max_price = 1.0