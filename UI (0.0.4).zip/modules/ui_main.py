# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainVYMedd.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1195, 714)
        font = QFont()
        font.setPointSize(10)
        MainWindow.setFont(font)
        MainWindow.setStyleSheet(u"")
        self.styleSheet = QWidget(MainWindow)
        self.styleSheet.setObjectName(u"styleSheet")
        self.styleSheet.setFont(font)
        self.styleSheet.setStyleSheet(u"background-color:#121212;\n"
"color: #ffffff;")
        self.vboxLayout = QVBoxLayout(self.styleSheet)
        self.vboxLayout.setSpacing(0)
        self.vboxLayout.setObjectName(u"vboxLayout")
        self.vboxLayout.setContentsMargins(0, 0, 0, 0)
        self.bgApp = QFrame(self.styleSheet)
        self.bgApp.setObjectName(u"bgApp")
        self.bgApp.setMinimumSize(QSize(782, 0))
        self.bgApp.setMaximumSize(QSize(16777215, 16777215))
        self.bgApp.setStyleSheet(u"")
        self.bgApp.setFrameShape(QFrame.NoFrame)
        self.bgApp.setFrameShadow(QFrame.Raised)
        self.bgApp.setLineWidth(1)
        self.horizontalLayout = QHBoxLayout(self.bgApp)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.leftMenuBg = QFrame(self.bgApp)
        self.leftMenuBg.setObjectName(u"leftMenuBg")
        self.leftMenuBg.setMinimumSize(QSize(0, 0))
        self.leftMenuBg.setMaximumSize(QSize(70, 16777215))
        self.leftMenuBg.setStyleSheet(u"")
        self.leftMenuBg.setFrameShape(QFrame.NoFrame)
        self.leftMenuBg.setFrameShadow(QFrame.Raised)
        self.leftMenuBg.setLineWidth(1)
        self.verticalLayout_4 = QVBoxLayout(self.leftMenuBg)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.topLogoInfo = QFrame(self.leftMenuBg)
        self.topLogoInfo.setObjectName(u"topLogoInfo")
        self.topLogoInfo.setMinimumSize(QSize(0, 60))
        self.topLogoInfo.setMaximumSize(QSize(16777215, 60))
        self.topLogoInfo.setStyleSheet(u"")
        self.topLogoInfo.setFrameShape(QFrame.NoFrame)
        self.topLogoInfo.setFrameShadow(QFrame.Raised)
        self.verticalLayout_12 = QVBoxLayout(self.topLogoInfo)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.frame = QFrame(self.topLogoInfo)
        self.frame.setObjectName(u"frame")
        self.frame.setStyleSheet(u"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)

        self.verticalLayout_12.addWidget(self.frame)


        self.verticalLayout_4.addWidget(self.topLogoInfo)

        self.leftMenuFrame = QFrame(self.leftMenuBg)
        self.leftMenuFrame.setObjectName(u"leftMenuFrame")
        self.leftMenuFrame.setFrameShape(QFrame.NoFrame)
        self.leftMenuFrame.setFrameShadow(QFrame.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.leftMenuFrame)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.toggleBox = QFrame(self.leftMenuFrame)
        self.toggleBox.setObjectName(u"toggleBox")
        self.toggleBox.setMinimumSize(QSize(0, 0))
        self.toggleBox.setMaximumSize(QSize(16777215, 60))
        self.toggleBox.setFrameShape(QFrame.NoFrame)
        self.toggleBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.toggleBox)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.Btn_Toggle = QPushButton(self.toggleBox)
        self.Btn_Toggle.setObjectName(u"Btn_Toggle")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Btn_Toggle.sizePolicy().hasHeightForWidth())
        self.Btn_Toggle.setSizePolicy(sizePolicy)
        self.Btn_Toggle.setMinimumSize(QSize(0, 60))
        self.Btn_Toggle.setMaximumSize(QSize(16777215, 16777215))
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(False)
        font1.setWeight(50)
        self.Btn_Toggle.setFont(font1)
        self.Btn_Toggle.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.verticalLayout_9.addWidget(self.Btn_Toggle)


        self.verticalLayout_8.addWidget(self.toggleBox)

        self.topMenu = QFrame(self.leftMenuFrame)
        self.topMenu.setObjectName(u"topMenu")
        self.topMenu.setMinimumSize(QSize(0, 180))
        self.topMenu.setMaximumSize(QSize(16777215, 180))
        self.topMenu.setFrameShape(QFrame.NoFrame)
        self.topMenu.setFrameShadow(QFrame.Raised)
        self.verticalLayout_10 = QVBoxLayout(self.topMenu)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.Btn_home = QPushButton(self.topMenu)
        self.Btn_home.setObjectName(u"Btn_home")
        sizePolicy.setHeightForWidth(self.Btn_home.sizePolicy().hasHeightForWidth())
        self.Btn_home.setSizePolicy(sizePolicy)
        self.Btn_home.setMinimumSize(QSize(0, 60))
        self.Btn_home.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_home.setFont(font1)
        self.Btn_home.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.verticalLayout_10.addWidget(self.Btn_home)

        self.Btn_dde = QPushButton(self.topMenu)
        self.Btn_dde.setObjectName(u"Btn_dde")
        sizePolicy.setHeightForWidth(self.Btn_dde.sizePolicy().hasHeightForWidth())
        self.Btn_dde.setSizePolicy(sizePolicy)
        self.Btn_dde.setMinimumSize(QSize(0, 60))
        self.Btn_dde.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_dde.setFont(font1)
        self.Btn_dde.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.verticalLayout_10.addWidget(self.Btn_dde)

        self.Btn_trade_settings = QPushButton(self.topMenu)
        self.Btn_trade_settings.setObjectName(u"Btn_trade_settings")
        sizePolicy.setHeightForWidth(self.Btn_trade_settings.sizePolicy().hasHeightForWidth())
        self.Btn_trade_settings.setSizePolicy(sizePolicy)
        self.Btn_trade_settings.setMinimumSize(QSize(0, 60))
        self.Btn_trade_settings.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_trade_settings.setFont(font1)
        self.Btn_trade_settings.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.verticalLayout_10.addWidget(self.Btn_trade_settings)


        self.verticalLayout_8.addWidget(self.topMenu, 0, Qt.AlignTop)

        self.bottomMenu = QFrame(self.leftMenuFrame)
        self.bottomMenu.setObjectName(u"bottomMenu")
        self.bottomMenu.setMinimumSize(QSize(0, 0))
        self.bottomMenu.setMaximumSize(QSize(16777215, 16777215))
        self.bottomMenu.setStyleSheet(u"")
        self.bottomMenu.setFrameShape(QFrame.NoFrame)
        self.bottomMenu.setFrameShadow(QFrame.Raised)
        self.verticalLayout_11 = QVBoxLayout(self.bottomMenu)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.Btn_Settings = QPushButton(self.bottomMenu)
        self.Btn_Settings.setObjectName(u"Btn_Settings")
        sizePolicy.setHeightForWidth(self.Btn_Settings.sizePolicy().hasHeightForWidth())
        self.Btn_Settings.setSizePolicy(sizePolicy)
        self.Btn_Settings.setMinimumSize(QSize(0, 60))
        self.Btn_Settings.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_Settings.setFont(font1)
        self.Btn_Settings.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")
        self.Btn_Settings.setIconSize(QSize(20, 20))

        self.verticalLayout_11.addWidget(self.Btn_Settings)


        self.verticalLayout_8.addWidget(self.bottomMenu, 0, Qt.AlignBottom)


        self.verticalLayout_4.addWidget(self.leftMenuFrame)


        self.horizontalLayout.addWidget(self.leftMenuBg)

        self.extraLeftBox = QFrame(self.bgApp)
        self.extraLeftBox.setObjectName(u"extraLeftBox")
        self.extraLeftBox.setMinimumSize(QSize(0, 0))
        self.extraLeftBox.setMaximumSize(QSize(0, 16777215))
        self.extraLeftBox.setStyleSheet(u"background-color: #ADBED2;")
        self.extraLeftBox.setFrameShape(QFrame.NoFrame)
        self.extraLeftBox.setFrameShadow(QFrame.Raised)
        self.extraLeftBox.setLineWidth(1)
        self.verticalLayout_5 = QVBoxLayout(self.extraLeftBox)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_2 = QFrame(self.extraLeftBox)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setMinimumSize(QSize(0, 60))
        self.frame_2.setMaximumSize(QSize(16777215, 60))
        self.frame_2.setStyleSheet(u"background-color:#EB8F90;")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame_2)
        self.gridLayout.setObjectName(u"gridLayout")
        self.extraIcon = QFrame(self.frame_2)
        self.extraIcon.setObjectName(u"extraIcon")
        self.extraIcon.setMinimumSize(QSize(0, 30))
        self.extraIcon.setFrameShape(QFrame.StyledPanel)
        self.extraIcon.setFrameShadow(QFrame.Raised)

        self.gridLayout.addWidget(self.extraIcon, 0, 0, 1, 1)

        self.extraLabel = QLabel(self.frame_2)
        self.extraLabel.setObjectName(u"extraLabel")
        self.extraLabel.setMinimumSize(QSize(0, 30))

        self.gridLayout.addWidget(self.extraLabel, 0, 1, 1, 1)

        self.extraCloseColumnBtn = QPushButton(self.frame_2)
        self.extraCloseColumnBtn.setObjectName(u"extraCloseColumnBtn")
        self.extraCloseColumnBtn.setMinimumSize(QSize(0, 30))
        self.extraCloseColumnBtn.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #FFB471}")

        self.gridLayout.addWidget(self.extraCloseColumnBtn, 0, 2, 1, 1)


        self.verticalLayout_5.addWidget(self.frame_2)

        self.frame_3 = QFrame(self.extraLeftBox)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setStyleSheet(u"")
        self.frame_3.setFrameShape(QFrame.NoFrame)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.verticalLayout_19 = QVBoxLayout(self.frame_3)
        self.verticalLayout_19.setSpacing(0)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(0, 0, 0, 0)
        self.frame_6 = QFrame(self.frame_3)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setStyleSheet(u"")
        self.frame_6.setFrameShape(QFrame.NoFrame)
        self.frame_6.setFrameShadow(QFrame.Raised)
        self.verticalLayout_20 = QVBoxLayout(self.frame_6)
        self.verticalLayout_20.setSpacing(0)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.verticalLayout_20.setContentsMargins(0, 0, 0, 0)
        self.frame_9 = QFrame(self.frame_6)
        self.frame_9.setObjectName(u"frame_9")
        self.frame_9.setStyleSheet(u"")
        self.frame_9.setFrameShape(QFrame.NoFrame)
        self.frame_9.setFrameShadow(QFrame.Raised)
        self.verticalLayout_21 = QVBoxLayout(self.frame_9)
        self.verticalLayout_21.setSpacing(0)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.verticalLayout_21.setContentsMargins(0, 0, 0, 0)
        self.Btn_widget = QPushButton(self.frame_9)
        self.Btn_widget.setObjectName(u"Btn_widget")
        self.Btn_widget.setMinimumSize(QSize(0, 50))
        font2 = QFont()
        font2.setPointSize(12)
        font2.setBold(False)
        font2.setWeight(50)
        self.Btn_widget.setFont(font2)
        self.Btn_widget.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #FFB471}")

        self.verticalLayout_21.addWidget(self.Btn_widget)

        self.Btn_file = QPushButton(self.frame_9)
        self.Btn_file.setObjectName(u"Btn_file")
        self.Btn_file.setMinimumSize(QSize(0, 50))
        self.Btn_file.setFont(font2)
        self.Btn_file.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #FFB471}")

        self.verticalLayout_21.addWidget(self.Btn_file)

        self.Btn_info = QPushButton(self.frame_9)
        self.Btn_info.setObjectName(u"Btn_info")
        self.Btn_info.setMinimumSize(QSize(0, 50))
        self.Btn_info.setFont(font2)
        self.Btn_info.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #FFB471}")

        self.verticalLayout_21.addWidget(self.Btn_info)


        self.verticalLayout_20.addWidget(self.frame_9, 0, Qt.AlignTop)


        self.verticalLayout_19.addWidget(self.frame_6)

        self.frame_7 = QFrame(self.frame_3)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setMaximumSize(QSize(16777215, 30))
        self.frame_7.setStyleSheet(u"background-color:#EB8F90;")
        self.frame_7.setFrameShape(QFrame.StyledPanel)
        self.frame_7.setFrameShadow(QFrame.Raised)

        self.verticalLayout_19.addWidget(self.frame_7)


        self.verticalLayout_5.addWidget(self.frame_3)


        self.horizontalLayout.addWidget(self.extraLeftBox)

        self.contentBox = QFrame(self.bgApp)
        self.contentBox.setObjectName(u"contentBox")
        self.contentBox.setStyleSheet(u"")
        self.contentBox.setFrameShape(QFrame.NoFrame)
        self.contentBox.setFrameShadow(QFrame.Raised)
        self.contentBox.setLineWidth(1)
        self.verticalLayout = QVBoxLayout(self.contentBox)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.contentTopBg = QFrame(self.contentBox)
        self.contentTopBg.setObjectName(u"contentTopBg")
        self.contentTopBg.setMinimumSize(QSize(0, 0))
        self.contentTopBg.setMaximumSize(QSize(16777215, 60))
        self.contentTopBg.setStyleSheet(u"")
        self.contentTopBg.setFrameShape(QFrame.NoFrame)
        self.contentTopBg.setFrameShadow(QFrame.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.contentTopBg)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.contentTop_1 = QFrame(self.contentTopBg)
        self.contentTop_1.setObjectName(u"contentTop_1")
        self.contentTop_1.setMinimumSize(QSize(0, 30))
        self.contentTop_1.setFrameShape(QFrame.StyledPanel)
        self.contentTop_1.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.contentTop_1)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.LeftTopLabel = QFrame(self.contentTop_1)
        self.LeftTopLabel.setObjectName(u"LeftTopLabel")
        self.LeftTopLabel.setFrameShape(QFrame.StyledPanel)
        self.LeftTopLabel.setFrameShadow(QFrame.Raised)
        self.verticalLayout_17 = QVBoxLayout(self.LeftTopLabel)
        self.verticalLayout_17.setSpacing(0)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(0, 0, 0, 0)
        self.Label_title = QLabel(self.LeftTopLabel)
        self.Label_title.setObjectName(u"Label_title")
        self.Label_title.setStyleSheet(u"")

        self.verticalLayout_17.addWidget(self.Label_title)


        self.horizontalLayout_4.addWidget(self.LeftTopLabel)

        self.RigthTopMenuBox = QFrame(self.contentTop_1)
        self.RigthTopMenuBox.setObjectName(u"RigthTopMenuBox")
        self.RigthTopMenuBox.setMinimumSize(QSize(0, 30))
        self.RigthTopMenuBox.setMaximumSize(QSize(16777215, 16777215))
        self.RigthTopMenuBox.setFrameShape(QFrame.NoFrame)
        self.RigthTopMenuBox.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.RigthTopMenuBox)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.Btn_Minimize = QPushButton(self.RigthTopMenuBox)
        self.Btn_Minimize.setObjectName(u"Btn_Minimize")
        self.Btn_Minimize.setMinimumSize(QSize(45, 30))
        self.Btn_Minimize.setMaximumSize(QSize(45, 30))
        font3 = QFont()
        font3.setPointSize(9)
        font3.setBold(False)
        font3.setWeight(50)
        self.Btn_Minimize.setFont(font3)
        self.Btn_Minimize.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.horizontalLayout_5.addWidget(self.Btn_Minimize)

        self.Btn_MaximizeRestore = QPushButton(self.RigthTopMenuBox)
        self.Btn_MaximizeRestore.setObjectName(u"Btn_MaximizeRestore")
        self.Btn_MaximizeRestore.setMinimumSize(QSize(45, 30))
        self.Btn_MaximizeRestore.setMaximumSize(QSize(45, 30))
        self.Btn_MaximizeRestore.setFont(font3)
        self.Btn_MaximizeRestore.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.horizontalLayout_5.addWidget(self.Btn_MaximizeRestore)

        self.Btn_Close = QPushButton(self.RigthTopMenuBox)
        self.Btn_Close.setObjectName(u"Btn_Close")
        self.Btn_Close.setMinimumSize(QSize(45, 30))
        self.Btn_Close.setMaximumSize(QSize(45, 30))
        self.Btn_Close.setFont(font3)
        self.Btn_Close.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: rgba(255,0,0,255)}")

        self.horizontalLayout_5.addWidget(self.Btn_Close)


        self.horizontalLayout_4.addWidget(self.RigthTopMenuBox, 0, Qt.AlignRight)


        self.verticalLayout_13.addWidget(self.contentTop_1)

        self.contentTop_2 = QFrame(self.contentTopBg)
        self.contentTop_2.setObjectName(u"contentTop_2")
        self.contentTop_2.setMinimumSize(QSize(0, 30))
        self.contentTop_2.setFrameShape(QFrame.NoFrame)
        self.contentTop_2.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_6 = QHBoxLayout(self.contentTop_2)
        self.horizontalLayout_6.setSpacing(0)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.frame_8 = QFrame(self.contentTop_2)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setFrameShape(QFrame.NoFrame)
        self.frame_8.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_7 = QHBoxLayout(self.frame_8)
        self.horizontalLayout_7.setSpacing(0)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.frame_11 = QFrame(self.frame_8)
        self.frame_11.setObjectName(u"frame_11")
        self.frame_11.setMaximumSize(QSize(500, 16777215))
        self.frame_11.setFrameShape(QFrame.NoFrame)
        self.frame_11.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_8 = QHBoxLayout(self.frame_11)
        self.horizontalLayout_8.setSpacing(5)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.Btn_Search = QPushButton(self.frame_11)
        self.Btn_Search.setObjectName(u"Btn_Search")
        self.Btn_Search.setMinimumSize(QSize(25, 25))
        self.Btn_Search.setMaximumSize(QSize(25, 25))
        self.Btn_Search.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.horizontalLayout_8.addWidget(self.Btn_Search)

        self.lineEdit = QLineEdit(self.frame_11)
        self.lineEdit.setObjectName(u"lineEdit")
        sizePolicy.setHeightForWidth(self.lineEdit.sizePolicy().hasHeightForWidth())
        self.lineEdit.setSizePolicy(sizePolicy)
        self.lineEdit.setMinimumSize(QSize(0, 25))

        self.horizontalLayout_8.addWidget(self.lineEdit)


        self.horizontalLayout_7.addWidget(self.frame_11)

        self.frame_12 = QFrame(self.frame_8)
        self.frame_12.setObjectName(u"frame_12")
        self.frame_12.setMinimumSize(QSize(0, 0))
        self.frame_12.setFrameShape(QFrame.NoFrame)
        self.frame_12.setFrameShadow(QFrame.Raised)

        self.horizontalLayout_7.addWidget(self.frame_12)


        self.horizontalLayout_6.addWidget(self.frame_8)

        self.frame_10 = QFrame(self.contentTop_2)
        self.frame_10.setObjectName(u"frame_10")
        self.frame_10.setMaximumSize(QSize(200, 16777215))
        self.frame_10.setFrameShape(QFrame.NoFrame)
        self.frame_10.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_9 = QHBoxLayout(self.frame_10)
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.Btn_extraRightBox = QPushButton(self.frame_10)
        self.Btn_extraRightBox.setObjectName(u"Btn_extraRightBox")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.Btn_extraRightBox.sizePolicy().hasHeightForWidth())
        self.Btn_extraRightBox.setSizePolicy(sizePolicy1)
        self.Btn_extraRightBox.setMinimumSize(QSize(0, 0))
        self.Btn_extraRightBox.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_extraRightBox.setFont(font1)
        self.Btn_extraRightBox.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.horizontalLayout_9.addWidget(self.Btn_extraRightBox)

        self.Btn_Etc = QPushButton(self.frame_10)
        self.Btn_Etc.setObjectName(u"Btn_Etc")
        sizePolicy1.setHeightForWidth(self.Btn_Etc.sizePolicy().hasHeightForWidth())
        self.Btn_Etc.setSizePolicy(sizePolicy1)
        self.Btn_Etc.setMinimumSize(QSize(0, 0))
        self.Btn_Etc.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_Etc.setFont(font1)
        self.Btn_Etc.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")

        self.horizontalLayout_9.addWidget(self.Btn_Etc)


        self.horizontalLayout_6.addWidget(self.frame_10)


        self.verticalLayout_13.addWidget(self.contentTop_2)


        self.verticalLayout.addWidget(self.contentTopBg)

        self.contentBottom = QFrame(self.contentBox)
        self.contentBottom.setObjectName(u"contentBottom")
        self.contentBottom.setFrameShape(QFrame.NoFrame)
        self.contentBottom.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.contentBottom)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.content = QFrame(self.contentBottom)
        self.content.setObjectName(u"content")
        self.content.setStyleSheet(u"")
        self.content.setFrameShape(QFrame.NoFrame)
        self.content.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.content)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.PageBox = QFrame(self.content)
        self.PageBox.setObjectName(u"PageBox")
        self.PageBox.setStyleSheet(u"background-color:#4D4847;")
        self.PageBox.setFrameShape(QFrame.NoFrame)
        self.PageBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.PageBox)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget = QStackedWidget(self.PageBox)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setStyleSheet(u"")
        self.stackedWidget.setFrameShadow(QFrame.Raised)
        self.page_home = QWidget()
        self.page_home.setObjectName(u"page_home")
        self.page_home.setStyleSheet(u"")
        self.verticalLayout_14 = QVBoxLayout(self.page_home)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.HomeBox = QFrame(self.page_home)
        self.HomeBox.setObjectName(u"HomeBox")
        self.HomeBox.setFrameShape(QFrame.StyledPanel)
        self.HomeBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_15 = QVBoxLayout(self.HomeBox)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")

        self.verticalLayout_14.addWidget(self.HomeBox)

        self.stackedWidget.addWidget(self.page_home)
        self.page_dde = QWidget()
        self.page_dde.setObjectName(u"page_dde")
        self.page_dde.setStyleSheet(u"")
        self.verticalLayout_16 = QVBoxLayout(self.page_dde)
        self.verticalLayout_16.setSpacing(0)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.PageDDEBox = QFrame(self.page_dde)
        self.PageDDEBox.setObjectName(u"PageDDEBox")
        self.PageDDEBox.setFrameShape(QFrame.StyledPanel)
        self.PageDDEBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_18 = QVBoxLayout(self.PageDDEBox)
        self.verticalLayout_18.setSpacing(0)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setContentsMargins(10, 0, 0, 0)
        self.tableWidget = QTableWidget(self.PageDDEBox)
        if (self.tableWidget.columnCount() < 12):
            self.tableWidget.setColumnCount(12)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(7, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(8, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(9, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(10, __qtablewidgetitem10)
        __qtablewidgetitem11 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(11, __qtablewidgetitem11)
        if (self.tableWidget.rowCount() < 20):
            self.tableWidget.setRowCount(20)
        __qtablewidgetitem12 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, __qtablewidgetitem12)
        __qtablewidgetitem13 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, __qtablewidgetitem13)
        __qtablewidgetitem14 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, __qtablewidgetitem14)
        __qtablewidgetitem15 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, __qtablewidgetitem15)
        __qtablewidgetitem16 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(4, __qtablewidgetitem16)
        __qtablewidgetitem17 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(5, __qtablewidgetitem17)
        __qtablewidgetitem18 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(6, __qtablewidgetitem18)
        __qtablewidgetitem19 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(7, __qtablewidgetitem19)
        __qtablewidgetitem20 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(8, __qtablewidgetitem20)
        __qtablewidgetitem21 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(9, __qtablewidgetitem21)
        __qtablewidgetitem22 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(10, __qtablewidgetitem22)
        __qtablewidgetitem23 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(11, __qtablewidgetitem23)
        __qtablewidgetitem24 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(12, __qtablewidgetitem24)
        __qtablewidgetitem25 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(13, __qtablewidgetitem25)
        __qtablewidgetitem26 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(14, __qtablewidgetitem26)
        __qtablewidgetitem27 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(15, __qtablewidgetitem27)
        __qtablewidgetitem28 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(16, __qtablewidgetitem28)
        __qtablewidgetitem29 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(17, __qtablewidgetitem29)
        __qtablewidgetitem30 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(18, __qtablewidgetitem30)
        __qtablewidgetitem31 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(19, __qtablewidgetitem31)
        __qtablewidgetitem32 = QTableWidgetItem()
        self.tableWidget.setItem(0, 1, __qtablewidgetitem32)
        font4 = QFont()
        font4.setPointSize(10)
        font4.setBold(True)
        font4.setWeight(75)
        __qtablewidgetitem33 = QTableWidgetItem()
        __qtablewidgetitem33.setFont(font4);
        self.tableWidget.setItem(0, 2, __qtablewidgetitem33)
        __qtablewidgetitem34 = QTableWidgetItem()
        __qtablewidgetitem34.setFont(font4);
        self.tableWidget.setItem(0, 3, __qtablewidgetitem34)
        __qtablewidgetitem35 = QTableWidgetItem()
        __qtablewidgetitem35.setFont(font4);
        self.tableWidget.setItem(0, 4, __qtablewidgetitem35)
        __qtablewidgetitem36 = QTableWidgetItem()
        __qtablewidgetitem36.setFont(font4);
        self.tableWidget.setItem(0, 5, __qtablewidgetitem36)
        __qtablewidgetitem37 = QTableWidgetItem()
        __qtablewidgetitem37.setFont(font4);
        self.tableWidget.setItem(0, 6, __qtablewidgetitem37)
        __qtablewidgetitem38 = QTableWidgetItem()
        __qtablewidgetitem38.setFont(font4);
        self.tableWidget.setItem(0, 7, __qtablewidgetitem38)
        __qtablewidgetitem39 = QTableWidgetItem()
        __qtablewidgetitem39.setFont(font4);
        self.tableWidget.setItem(0, 8, __qtablewidgetitem39)
        __qtablewidgetitem40 = QTableWidgetItem()
        self.tableWidget.setItem(1, 1, __qtablewidgetitem40)
        __qtablewidgetitem41 = QTableWidgetItem()
        self.tableWidget.setItem(1, 2, __qtablewidgetitem41)
        __qtablewidgetitem42 = QTableWidgetItem()
        self.tableWidget.setItem(1, 3, __qtablewidgetitem42)
        __qtablewidgetitem43 = QTableWidgetItem()
        __qtablewidgetitem43.setFont(font4);
        self.tableWidget.setItem(2, 0, __qtablewidgetitem43)
        __qtablewidgetitem44 = QTableWidgetItem()
        __qtablewidgetitem44.setFont(font4);
        self.tableWidget.setItem(2, 1, __qtablewidgetitem44)
        __qtablewidgetitem45 = QTableWidgetItem()
        __qtablewidgetitem45.setFont(font4);
        self.tableWidget.setItem(2, 2, __qtablewidgetitem45)
        __qtablewidgetitem46 = QTableWidgetItem()
        __qtablewidgetitem46.setFont(font4);
        self.tableWidget.setItem(2, 3, __qtablewidgetitem46)
        __qtablewidgetitem47 = QTableWidgetItem()
        __qtablewidgetitem47.setFont(font4);
        self.tableWidget.setItem(2, 4, __qtablewidgetitem47)
        __qtablewidgetitem48 = QTableWidgetItem()
        __qtablewidgetitem48.setFont(font4);
        self.tableWidget.setItem(2, 5, __qtablewidgetitem48)
        __qtablewidgetitem49 = QTableWidgetItem()
        __qtablewidgetitem49.setFont(font4);
        self.tableWidget.setItem(2, 6, __qtablewidgetitem49)
        __qtablewidgetitem50 = QTableWidgetItem()
        __qtablewidgetitem50.setFont(font4);
        self.tableWidget.setItem(2, 7, __qtablewidgetitem50)
        __qtablewidgetitem51 = QTableWidgetItem()
        __qtablewidgetitem51.setFont(font4);
        self.tableWidget.setItem(2, 8, __qtablewidgetitem51)
        __qtablewidgetitem52 = QTableWidgetItem()
        __qtablewidgetitem52.setFont(font4);
        self.tableWidget.setItem(2, 9, __qtablewidgetitem52)
        __qtablewidgetitem53 = QTableWidgetItem()
        __qtablewidgetitem53.setFont(font4);
        self.tableWidget.setItem(2, 10, __qtablewidgetitem53)
        __qtablewidgetitem54 = QTableWidgetItem()
        __qtablewidgetitem54.setFont(font4);
        self.tableWidget.setItem(2, 11, __qtablewidgetitem54)
        __qtablewidgetitem55 = QTableWidgetItem()
        self.tableWidget.setItem(3, 4, __qtablewidgetitem55)
        font5 = QFont()
        font5.setPointSize(12)
        font5.setBold(True)
        font5.setWeight(75)
        __qtablewidgetitem56 = QTableWidgetItem()
        __qtablewidgetitem56.setFont(font5);
        self.tableWidget.setItem(3, 5, __qtablewidgetitem56)
        __qtablewidgetitem57 = QTableWidgetItem()
        __qtablewidgetitem57.setFont(font5);
        self.tableWidget.setItem(4, 5, __qtablewidgetitem57)
        __qtablewidgetitem58 = QTableWidgetItem()
        __qtablewidgetitem58.setFont(font5);
        self.tableWidget.setItem(5, 5, __qtablewidgetitem58)
        __qtablewidgetitem59 = QTableWidgetItem()
        __qtablewidgetitem59.setFont(font5);
        self.tableWidget.setItem(6, 5, __qtablewidgetitem59)
        __qtablewidgetitem60 = QTableWidgetItem()
        __qtablewidgetitem60.setFont(font5);
        self.tableWidget.setItem(7, 5, __qtablewidgetitem60)
        __qtablewidgetitem61 = QTableWidgetItem()
        __qtablewidgetitem61.setFont(font5);
        self.tableWidget.setItem(8, 5, __qtablewidgetitem61)
        __qtablewidgetitem62 = QTableWidgetItem()
        __qtablewidgetitem62.setFont(font5);
        self.tableWidget.setItem(9, 5, __qtablewidgetitem62)
        __qtablewidgetitem63 = QTableWidgetItem()
        __qtablewidgetitem63.setFont(font5);
        self.tableWidget.setItem(10, 5, __qtablewidgetitem63)
        __qtablewidgetitem64 = QTableWidgetItem()
        __qtablewidgetitem64.setFont(font5);
        self.tableWidget.setItem(11, 5, __qtablewidgetitem64)
        __qtablewidgetitem65 = QTableWidgetItem()
        __qtablewidgetitem65.setFont(font5);
        self.tableWidget.setItem(12, 5, __qtablewidgetitem65)
        __qtablewidgetitem66 = QTableWidgetItem()
        __qtablewidgetitem66.setFont(font5);
        self.tableWidget.setItem(13, 5, __qtablewidgetitem66)
        __qtablewidgetitem67 = QTableWidgetItem()
        __qtablewidgetitem67.setFont(font5);
        self.tableWidget.setItem(14, 5, __qtablewidgetitem67)
        __qtablewidgetitem68 = QTableWidgetItem()
        __qtablewidgetitem68.setFont(font5);
        self.tableWidget.setItem(15, 5, __qtablewidgetitem68)
        __qtablewidgetitem69 = QTableWidgetItem()
        __qtablewidgetitem69.setFont(font5);
        self.tableWidget.setItem(16, 5, __qtablewidgetitem69)
        __qtablewidgetitem70 = QTableWidgetItem()
        __qtablewidgetitem70.setFont(font5);
        self.tableWidget.setItem(17, 5, __qtablewidgetitem70)
        __qtablewidgetitem71 = QTableWidgetItem()
        __qtablewidgetitem71.setFont(font5);
        self.tableWidget.setItem(18, 5, __qtablewidgetitem71)
        __qtablewidgetitem72 = QTableWidgetItem()
        __qtablewidgetitem72.setFont(font5);
        self.tableWidget.setItem(19, 5, __qtablewidgetitem72)
        self.tableWidget.setObjectName(u"tableWidget")
        font6 = QFont()
        font6.setPointSize(11)
        font6.setBold(False)
        font6.setWeight(50)
        self.tableWidget.setFont(font6)
        self.tableWidget.setStyleSheet(u"")
        self.tableWidget.setFrameShape(QFrame.NoFrame)
        self.tableWidget.horizontalHeader().setVisible(False)
        self.tableWidget.verticalHeader().setVisible(False)

        self.verticalLayout_18.addWidget(self.tableWidget)


        self.verticalLayout_16.addWidget(self.PageDDEBox)

        self.stackedWidget.addWidget(self.page_dde)
        self.page_trading = QWidget()
        self.page_trading.setObjectName(u"page_trading")
        self.verticalLayout_22 = QVBoxLayout(self.page_trading)
        self.verticalLayout_22.setSpacing(0)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.verticalLayout_22.setContentsMargins(0, 0, 0, 0)
        self.trader_settingBox = QFrame(self.page_trading)
        self.trader_settingBox.setObjectName(u"trader_settingBox")
        self.trader_settingBox.setFrameShape(QFrame.StyledPanel)
        self.trader_settingBox.setFrameShadow(QFrame.Raised)
        self.sOrder_frame = QFrame(self.trader_settingBox)
        self.sOrder_frame.setObjectName(u"sOrder_frame")
        self.sOrder_frame.setGeometry(QRect(10, 10, 207, 54))
        self.sOrder_frame.setFrameShape(QFrame.NoFrame)
        self.sOrder_frame.setFrameShadow(QFrame.Raised)
        self.gridLayout_2 = QGridLayout(self.sOrder_frame)
        self.gridLayout_2.setSpacing(0)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.radioButton = QRadioButton(self.sOrder_frame)
        self.radioButton.setObjectName(u"radioButton")

        self.gridLayout_2.addWidget(self.radioButton, 1, 0, 1, 1)

        self.radioButton_2 = QRadioButton(self.sOrder_frame)
        self.radioButton_2.setObjectName(u"radioButton_2")

        self.gridLayout_2.addWidget(self.radioButton_2, 1, 1, 1, 1)

        self.label = QLabel(self.sOrder_frame)
        self.label.setObjectName(u"label")

        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 2)


        self.verticalLayout_22.addWidget(self.trader_settingBox)

        self.stackedWidget.addWidget(self.page_trading)

        self.verticalLayout_3.addWidget(self.stackedWidget)


        self.horizontalLayout_2.addWidget(self.PageBox)

        self.extraRightBox = QFrame(self.content)
        self.extraRightBox.setObjectName(u"extraRightBox")
        self.extraRightBox.setMinimumSize(QSize(0, 0))
        self.extraRightBox.setMaximumSize(QSize(0, 16777215))
        self.extraRightBox.setStyleSheet(u"background-color: #ADBED2;")
        self.extraRightBox.setFrameShape(QFrame.NoFrame)
        self.extraRightBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.extraRightBox)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.frame_4 = QFrame(self.extraRightBox)
        self.frame_4.setObjectName(u"frame_4")
        sizePolicy1.setHeightForWidth(self.frame_4.sizePolicy().hasHeightForWidth())
        self.frame_4.setSizePolicy(sizePolicy1)
        self.frame_4.setMinimumSize(QSize(0, 0))
        self.frame_4.setMaximumSize(QSize(16777215, 120))
        self.frame_4.setStyleSheet(u"background-color:#EB8F90;")
        self.frame_4.setFrameShape(QFrame.NoFrame)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_4)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.Btn_Login = QPushButton(self.frame_4)
        self.Btn_Login.setObjectName(u"Btn_Login")
        sizePolicy1.setHeightForWidth(self.Btn_Login.sizePolicy().hasHeightForWidth())
        self.Btn_Login.setSizePolicy(sizePolicy1)
        self.Btn_Login.setMinimumSize(QSize(0, 0))
        self.Btn_Login.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_Login.setFont(font2)
        self.Btn_Login.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #FFB471}")

        self.verticalLayout_7.addWidget(self.Btn_Login)

        self.Btn_RealData = QPushButton(self.frame_4)
        self.Btn_RealData.setObjectName(u"Btn_RealData")
        sizePolicy1.setHeightForWidth(self.Btn_RealData.sizePolicy().hasHeightForWidth())
        self.Btn_RealData.setSizePolicy(sizePolicy1)
        self.Btn_RealData.setMinimumSize(QSize(0, 0))
        self.Btn_RealData.setFont(font2)
        self.Btn_RealData.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);border: 0px solid}\n"
"QPushButton:hover {background-color: #FFB471}")

        self.verticalLayout_7.addWidget(self.Btn_RealData)


        self.verticalLayout_6.addWidget(self.frame_4)

        self.frame_5 = QFrame(self.extraRightBox)
        self.frame_5.setObjectName(u"frame_5")
        sizePolicy1.setHeightForWidth(self.frame_5.sizePolicy().hasHeightForWidth())
        self.frame_5.setSizePolicy(sizePolicy1)
        self.frame_5.setFrameShape(QFrame.NoFrame)
        self.frame_5.setFrameShadow(QFrame.Raised)

        self.verticalLayout_6.addWidget(self.frame_5)


        self.horizontalLayout_2.addWidget(self.extraRightBox)


        self.verticalLayout_2.addWidget(self.content)

        self.BottomBox = QFrame(self.contentBottom)
        self.BottomBox.setObjectName(u"BottomBox")
        self.BottomBox.setMinimumSize(QSize(0, 30))
        self.BottomBox.setMaximumSize(QSize(16777215, 30))
        font7 = QFont()
        font7.setBold(False)
        font7.setWeight(50)
        self.BottomBox.setFont(font7)
        self.BottomBox.setStyleSheet(u"")
        self.BottomBox.setFrameShape(QFrame.NoFrame)
        self.BottomBox.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.BottomBox)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(2, 0, 6, 0)
        self.LoginStateLabel = QLabel(self.BottomBox)
        self.LoginStateLabel.setObjectName(u"LoginStateLabel")
        self.LoginStateLabel.setFont(font3)
        self.LoginStateLabel.setStyleSheet(u"color: rgb(255, 0, 0);")
        self.LoginStateLabel.setFrameShadow(QFrame.Raised)

        self.horizontalLayout_3.addWidget(self.LoginStateLabel)

        self.label_version = QLabel(self.BottomBox)
        self.label_version.setObjectName(u"label_version")
        self.label_version.setFont(font7)
        self.label_version.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.horizontalLayout_3.addWidget(self.label_version)


        self.verticalLayout_2.addWidget(self.BottomBox)


        self.verticalLayout.addWidget(self.contentBottom)


        self.horizontalLayout.addWidget(self.contentBox)

        self.contentBox.raise_()
        self.leftMenuBg.raise_()
        self.extraLeftBox.raise_()

        self.vboxLayout.addWidget(self.bgApp)

        MainWindow.setCentralWidget(self.styleSheet)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.Btn_Toggle.setText(QCoreApplication.translate("MainWindow", u"TOGGLE", None))
        self.Btn_home.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.Btn_dde.setText(QCoreApplication.translate("MainWindow", u"DDE", None))
        self.Btn_trade_settings.setText(QCoreApplication.translate("MainWindow", u"TRADE", None))
        self.Btn_Settings.setText(QCoreApplication.translate("MainWindow", u"Setting", None))
        self.extraLabel.setText(QCoreApplication.translate("MainWindow", u"TEXT", None))
        self.extraCloseColumnBtn.setText(QCoreApplication.translate("MainWindow", u"EXIT", None))
        self.Btn_widget.setText(QCoreApplication.translate("MainWindow", u"WIDGET", None))
        self.Btn_file.setText(QCoreApplication.translate("MainWindow", u"FILE", None))
        self.Btn_info.setText(QCoreApplication.translate("MainWindow", u"INFO", None))
        self.Label_title.setText(QCoreApplication.translate("MainWindow", u"TextLabel", None))
        self.Btn_Minimize.setText(QCoreApplication.translate("MainWindow", u"M", None))
        self.Btn_MaximizeRestore.setText(QCoreApplication.translate("MainWindow", u"M/R", None))
        self.Btn_Close.setText(QCoreApplication.translate("MainWindow", u"EXIT", None))
        self.Btn_Search.setText(QCoreApplication.translate("MainWindow", u"Q", None))
        self.Btn_extraRightBox.setText(QCoreApplication.translate("MainWindow", u"LOGIN", None))
        self.Btn_Etc.setText(QCoreApplication.translate("MainWindow", u"ETC", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"\ub9c8\ub514\uac00", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"\uc800\uac00", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"\uace0\uac00", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"\uc2dc\uac00", None));
        ___qtablewidgetitem4 = self.tableWidget.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"\ud604\uc7ac\uac00", None));
        ___qtablewidgetitem5 = self.tableWidget.horizontalHeaderItem(5)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"\ud589\uc0ac\uac00", None));
        ___qtablewidgetitem6 = self.tableWidget.horizontalHeaderItem(6)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"\ud604\uc7ac\uac00", None));
        ___qtablewidgetitem7 = self.tableWidget.horizontalHeaderItem(7)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"\uc2dc\uac00", None));
        ___qtablewidgetitem8 = self.tableWidget.horizontalHeaderItem(8)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("MainWindow", u"\uace0\uac00", None));
        ___qtablewidgetitem9 = self.tableWidget.horizontalHeaderItem(9)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("MainWindow", u"\uc800\uac00", None));
        ___qtablewidgetitem10 = self.tableWidget.horizontalHeaderItem(10)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("MainWindow", u"\ub9c8\ub514\uac00", None));
        ___qtablewidgetitem11 = self.tableWidget.horizontalHeaderItem(11)
        ___qtablewidgetitem11.setText(QCoreApplication.translate("MainWindow", u"\uad50\ucc28\uac00", None));
        ___qtablewidgetitem12 = self.tableWidget.verticalHeaderItem(0)
        ___qtablewidgetitem12.setText(QCoreApplication.translate("MainWindow", u"1", None));
        ___qtablewidgetitem13 = self.tableWidget.verticalHeaderItem(1)
        ___qtablewidgetitem13.setText(QCoreApplication.translate("MainWindow", u"2", None));
        ___qtablewidgetitem14 = self.tableWidget.verticalHeaderItem(2)
        ___qtablewidgetitem14.setText(QCoreApplication.translate("MainWindow", u"3", None));
        ___qtablewidgetitem15 = self.tableWidget.verticalHeaderItem(3)
        ___qtablewidgetitem15.setText(QCoreApplication.translate("MainWindow", u"4", None));
        ___qtablewidgetitem16 = self.tableWidget.verticalHeaderItem(4)
        ___qtablewidgetitem16.setText(QCoreApplication.translate("MainWindow", u"5", None));
        ___qtablewidgetitem17 = self.tableWidget.verticalHeaderItem(5)
        ___qtablewidgetitem17.setText(QCoreApplication.translate("MainWindow", u"6", None));
        ___qtablewidgetitem18 = self.tableWidget.verticalHeaderItem(6)
        ___qtablewidgetitem18.setText(QCoreApplication.translate("MainWindow", u"7", None));
        ___qtablewidgetitem19 = self.tableWidget.verticalHeaderItem(7)
        ___qtablewidgetitem19.setText(QCoreApplication.translate("MainWindow", u"8", None));
        ___qtablewidgetitem20 = self.tableWidget.verticalHeaderItem(8)
        ___qtablewidgetitem20.setText(QCoreApplication.translate("MainWindow", u"10", None));
        ___qtablewidgetitem21 = self.tableWidget.verticalHeaderItem(9)
        ___qtablewidgetitem21.setText(QCoreApplication.translate("MainWindow", u"11", None));
        ___qtablewidgetitem22 = self.tableWidget.verticalHeaderItem(10)
        ___qtablewidgetitem22.setText(QCoreApplication.translate("MainWindow", u"12", None));
        ___qtablewidgetitem23 = self.tableWidget.verticalHeaderItem(11)
        ___qtablewidgetitem23.setText(QCoreApplication.translate("MainWindow", u"13", None));
        ___qtablewidgetitem24 = self.tableWidget.verticalHeaderItem(12)
        ___qtablewidgetitem24.setText(QCoreApplication.translate("MainWindow", u"14", None));
        ___qtablewidgetitem25 = self.tableWidget.verticalHeaderItem(13)
        ___qtablewidgetitem25.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem26 = self.tableWidget.verticalHeaderItem(14)
        ___qtablewidgetitem26.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem27 = self.tableWidget.verticalHeaderItem(15)
        ___qtablewidgetitem27.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem28 = self.tableWidget.verticalHeaderItem(16)
        ___qtablewidgetitem28.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem29 = self.tableWidget.verticalHeaderItem(17)
        ___qtablewidgetitem29.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem30 = self.tableWidget.verticalHeaderItem(18)
        ___qtablewidgetitem30.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem31 = self.tableWidget.verticalHeaderItem(19)
        ___qtablewidgetitem31.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        ___qtablewidgetitem32 = self.tableWidget.item(0, 2)
        ___qtablewidgetitem32.setText(QCoreApplication.translate("MainWindow", u"\ud604\uc7ac\uac00", None));
        ___qtablewidgetitem33 = self.tableWidget.item(0, 3)
        ___qtablewidgetitem33.setText(QCoreApplication.translate("MainWindow", u"\uc2dc\uac00", None));
        ___qtablewidgetitem34 = self.tableWidget.item(0, 4)
        ___qtablewidgetitem34.setText(QCoreApplication.translate("MainWindow", u"\uace0\uac00", None));
        ___qtablewidgetitem35 = self.tableWidget.item(0, 5)
        ___qtablewidgetitem35.setText(QCoreApplication.translate("MainWindow", u"\uc800\uac00", None));
        ___qtablewidgetitem36 = self.tableWidget.item(0, 6)
        ___qtablewidgetitem36.setText(QCoreApplication.translate("MainWindow", u"KOSPI200", None));
        ___qtablewidgetitem37 = self.tableWidget.item(0, 7)
        ___qtablewidgetitem37.setText(QCoreApplication.translate("MainWindow", u"\ud638\uac00\uc21c\ub9e4\uc218", None));
        ___qtablewidgetitem38 = self.tableWidget.item(0, 8)
        ___qtablewidgetitem38.setText(QCoreApplication.translate("MainWindow", u"\ucd94\uc138", None));
        ___qtablewidgetitem39 = self.tableWidget.item(2, 0)
        ___qtablewidgetitem39.setText(QCoreApplication.translate("MainWindow", u"\ub9c8\ub514\uac00", None));
        ___qtablewidgetitem40 = self.tableWidget.item(2, 1)
        ___qtablewidgetitem40.setText(QCoreApplication.translate("MainWindow", u"\uc800\uac00", None));
        ___qtablewidgetitem41 = self.tableWidget.item(2, 2)
        ___qtablewidgetitem41.setText(QCoreApplication.translate("MainWindow", u"\uace0\uac00", None));
        ___qtablewidgetitem42 = self.tableWidget.item(2, 3)
        ___qtablewidgetitem42.setText(QCoreApplication.translate("MainWindow", u"\uc2dc\uac00", None));
        ___qtablewidgetitem43 = self.tableWidget.item(2, 4)
        ___qtablewidgetitem43.setText(QCoreApplication.translate("MainWindow", u"\ud604\uc7ac\uac00", None));
        ___qtablewidgetitem44 = self.tableWidget.item(2, 5)
        ___qtablewidgetitem44.setText(QCoreApplication.translate("MainWindow", u"\ud589\uc0ac\uac00", None));
        ___qtablewidgetitem45 = self.tableWidget.item(2, 6)
        ___qtablewidgetitem45.setText(QCoreApplication.translate("MainWindow", u"\ud604\uc7ac\uac00", None));
        ___qtablewidgetitem46 = self.tableWidget.item(2, 7)
        ___qtablewidgetitem46.setText(QCoreApplication.translate("MainWindow", u"\uc2dc\uac00", None));
        ___qtablewidgetitem47 = self.tableWidget.item(2, 8)
        ___qtablewidgetitem47.setText(QCoreApplication.translate("MainWindow", u"\uace0\uac00", None));
        ___qtablewidgetitem48 = self.tableWidget.item(2, 9)
        ___qtablewidgetitem48.setText(QCoreApplication.translate("MainWindow", u"\uc800\uac00", None));
        ___qtablewidgetitem49 = self.tableWidget.item(2, 10)
        ___qtablewidgetitem49.setText(QCoreApplication.translate("MainWindow", u"\ub9c8\ub514\uac00", None));
        ___qtablewidgetitem50 = self.tableWidget.item(2, 11)
        ___qtablewidgetitem50.setText(QCoreApplication.translate("MainWindow", u"\uad50\ucc28\uac00", None));
        self.tableWidget.setSortingEnabled(__sortingEnabled)

        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"\uc8fc\ubb38 \uc7a0\uae08", None))
        self.radioButton_2.setText(QCoreApplication.translate("MainWindow", u"\uc8fc\ubb38 \uc7a0\uae08\ud574\uc81c", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"\uc8fc\ubb38 \uc7a0\uae08 \uc124\uc815", None))
        self.Btn_Login.setText(QCoreApplication.translate("MainWindow", u"LOGIN", None))
        self.Btn_RealData.setText(QCoreApplication.translate("MainWindow", u"REAL DATA", None))
        self.LoginStateLabel.setText(QCoreApplication.translate("MainWindow", u"Unconnected", None))
        self.label_version.setText(QCoreApplication.translate("MainWindow", u"0.0.4", None))
    # retranslateUi

