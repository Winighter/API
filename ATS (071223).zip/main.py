import sys
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from modules import *
from widgets import *
from security import *

추세 = ''
counter = 1
class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_LoginScreen()
        self.ui.setupUi(self)
        self.setWindowTitle('ATS')
        UIFunctions.uiDefinitions(self)
        self.ui.Btn_Login.clicked.connect(self.onLogin)
        self.ui.Btn_Approve.clicked.connect(self.onLogin)
        self.ui.Btn_LoginApi.clicked.connect(self.onLogin)
        self.ui.Btn_Deny.clicked.connect(lambda: self.close())
        self.show()
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_login)


    def onLogin(self):
        self.ORDER = False
        btn = self.sender()
        btnName = btn.objectName()
        security_state = self.ui.checkBox_Security.isChecked()
        self.ORDER = self.ui.checkBox_Order.isChecked()
        if btnName == "Btn_Login":
            if security_state:
                SecurityManager()
            else:
                pass
            id = self.ui.LineEdit_ID.text()
            pw = self.ui.LineEdit_PW.text()

            if id == '' and pw == '':
                self.tr_event_loop = QEventLoop()
                AppFunctions.loginScreenState(self,0)
                self.ui.stackedWidget.setCurrentWidget(self.ui.page_otp)
                self.otp_code = SecurityManager.get_otpCode(self)
                self.ui.label_TOTP.setText(self.otp_code)
                self.timer = QTimer()
                self.timer.timeout.connect(self.update)
                self.timer.start(1000)
            else:
                AppFunctions.loginScreenState(self,1)

        if btnName == "Btn_Approve":
            self.timer.stop()
            self.ui.stackedWidget.setCurrentWidget(self.ui.page_setting)

        if btnName == 'Btn_LoginApi':
            self.tr_event_loop = QEventLoop()
            self.ui.stackedWidget.setCurrentWidget(self.ui.page_main)
            self.vLoss = int(self.ui.lineEdit_loss.text()) # 손절
            if self.vLoss > 0:
                self.vLoss = self.vLoss* -1
            self.vProfit = int(self.ui.lineEdit_profit.text()) # 이익
            self.vBMin = float(self.ui.lineEdit_buy_minimum.text()) # 최소 매수 가격
            self.vBMax = float(self.ui.lineEdit_buy_maxiimum.text()) # 최대 매수 가격
            self.vQuantity = int(self.ui.lineEdit_quantity.text()) # 매수 수량
            Kiwoom.onLogin(self)

    def update(self):
        global counter
        self.ui.label_totp_remaining_time.setText("%ss"%(10-counter))
        if counter >= 10:
            counter = 0
            self.ui.label_totp_remaining_time.setText("10s")
            self.ui.label_TOTP.setText(SecurityManager.get_otpCode(self))
        counter += 1

    def mousePressEvent(self, event):
        self.dragPos = event.globalPos()

    # KIWOOM TERRITORY
    def login_slot(self, err_code): # LOGIN EVENT
        if err_code != (0 and 1):
            print(errors(err_code)[1])
        else:
            Kiwoom.login_event_loop.exit()
            S.LOGIN_STATE = 1
            AppFunctions.loginState(self,0)
            Kiwoom.request_login_info(self)
            Kiwoom.request_option_price(self)
            Kiwoom.connect_real_data(self)
    # TR EVENT TERRITORY
    def trdata_slot(self, sScrNo, sRQName, sTrCode, sRecordName, sPrevNext):
        if sRQName == "옵션시세조회":
            oAct = []
            oCode = []
            cStr = []
            pStr = []
            rows = self.kiwoom.dynamicCall("GetRepeatCnt(QString, QString)", sTrCode, sRQName)
            for i in range(rows):
                cCode = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"종목코드")
                cCode = cCode.strip()

                cActPrice = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"행사가")
                cActPrice = float(cActPrice.strip())

                cPrice = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"현재가")
                cPrice = float(cPrice.strip().lstrip("+").lstrip("-"))

                cOpen = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"시가")
                cOpen = float(cOpen.strip().lstrip("+").lstrip("-"))

                cHigh = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"고가")
                cHigh = float(cHigh.strip().lstrip("+").lstrip("-"))

                cLow = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"저가")
                cLow = float(cLow.strip().lstrip("+").lstrip("-"))

                cKijoonka = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"기준가")
                cKijoonka = float(cKijoonka.strip().lstrip("+").lstrip("-"))

                pCode = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_종목코드")
                pCode = pCode.strip()

                pActPrice = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_행사가")
                pActPrice = float(pActPrice.strip())

                pPrice = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_현재가")
                pPrice = float(pPrice.strip().lstrip("+").lstrip("-"))

                pOpen = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_시가")
                pOpen = float(pOpen.strip().lstrip("+").lstrip("-"))

                pHigh = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_고가")
                pHigh = float(pHigh.strip().lstrip("+").lstrip("-"))

                pLow = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_저가")
                pLow = float(pLow.strip().lstrip("+").lstrip("-"))

                pKijoonka = self.kiwoom.dynamicCall("GetCommData(QString,QString,int,QString)",sTrCode,sRQName,i,"풋_기준가")
                pKijoonka = float(pKijoonka.strip().lstrip("+").lstrip("-"))

                S.option_table_dict.update({cCode: {"행사가": cActPrice,"현재가": cPrice,"시가": cOpen,"고가": cHigh,"저가": cLow}})
                S.option_table_dict.update({pCode:{"행사가": pActPrice,"현재가": pPrice,"시가": pOpen,"고가": pHigh,"저가": pLow}})

                if ((0.5 <= cOpen <= 10) or (0.5 <= pOpen <= 10)):
                    cStr.append(cCode)
                    pStr.append(pCode)
                    oCode.append(cCode)
                    oCode.append(pCode)
                    oAct.append(cActPrice)
                    oAct.append(pActPrice)
                    oAct = list(set(oAct))
                    oAct.sort()
                    i = len(oAct) + 2
                Kiwoom.Disconnect_All_Real(self)
            cStr.sort(reverse=True)
            pStr.sort(reverse=True)
            oCode.sort(reverse=True)
            self.cStr = ";".join(cStr)
            self.pStr = ";".join(pStr)
            self.oCode = oCode
            self.tr_event_loop.exit()


    def chejan_slot(self, Gubun, nItemCnt, sFidList):
        if int(Gubun) == 0:
            oCode = self.kiwoom.dynamicCall("GetChejanData(int)", 9001)  # 종목코드

            medosu = self.kiwoom.dynamicCall("GetChejanData(int)", 905)  # 구분
            medosu = medosu.strip().lstrip("+").lstrip("-")

            order_number = self.kiwoom.dynamicCall("GetChejanData(int)", 9203)  # 주문번호
            on = int(order_number)

            order_q = self.kiwoom.dynamicCall("GetChejanData(int)", 900)  # 주문수량
            order_q = int(order_q)

            un_quan = self.kiwoom.dynamicCall("GetChejanData(int)", 902)  # 미체결수량
            un_quan = int(un_quan)

            one_order_number = self.kiwoom.dynamicCall("GetChejanData(int)", 904)  # 원주문번호
            oon = int(one_order_number)

            order_price = self.kiwoom.dynamicCall("GetChejanData(int)", 901)  # 주문가격
            order_price = float(order_price)

            price = self.kiwoom.dynamicCall("GetChejanData(int)", 10)  # 현재가
            price = float(price)

            if un_quan == 0 and (("취소" not in medosu)):
                if medosu == '매도':
                    S.balance_dict = {}
                if medosu == "매수":
                    S.balance_dict.update({"종목코드": oCode,"구분": medosu,"수량": order_q,"매입단가": order_price,"현재가": price,"청산가능수량": order_q})
            else:
                if medosu != '정정':
                    S.correction_order_dict.update({"종목코드": oCode,"구분": medosu,"주문번호": on,"주문수량": order_q,"주문가격": order_price,"미체결수량": un_quan,"원주문번호": oon})


    def realdata_slot(self, oCode, RealType):
        global 추세
        if RealType == "선물호가잔량":
            a = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 128)  # 순매수잔량
            a = int(a)

            self.ui.label_FutureHoka.setText(str(format(a,',')))

            if 4000 <= a:
                추세 = 'CALL'
                self.ui.label_FutureHoka.setStyleSheet('color: #E81E25')

            elif -4000 >= a:
                추세 = 'PUT'
                self.ui.label_FutureHoka.setStyleSheet('color: #0359AE')


        elif RealType == "옵션시세":
            a = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 10)  # 현재가
            a = abs(float(a))

            b = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 16)  # 시가
            b = abs(float(b))

            c = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 17)  # 고가
            c = abs(float(c))

            d = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 18)  # 저가
            d = abs(float(d))

            e = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 28)  # (최우선)매수호가
            e = abs(float(e))

            f = self.kiwoom.dynamicCall("GetCommRealData(QString,int)", oCode, 137)  # 호가순잔량
            f = abs(float(f))

            if self.ORDER:
                # BUY ORDER TERRITORY
                if (S.balance_dict == {}) and (S.매수 == False) and (self.vBMin <= e <= self.vBMax) and (a >= b + 0.03):
                    if (oCode[0:1] == "2") and (추세 == "CALL"):
                        S.매수 = True
                        Kiwoom.request_orderFO(self, "신규매수", oCode, self.vQuantity, e, '','')

                    if (oCode[0:1] == "3") and (추세 == "PUT"):
                        S.매수 = True
                        Kiwoom.request_orderFO(self, "신규매수", oCode, self.vQuantity, e, '','')

                # SELL ORDER TERRITORY
                if S.balance_dict != {}:
                    if S.매수 == False:
                        S.매수 = True

                    if (oCode == S.balance_dict["종목코드"]) and (S.매수 == True):
                        buy_price = float(S.balance_dict["매입단가"])
                        주문가능수량 = int(S.balance_dict["청산가능수량"])
                        수익률 = (a - buy_price) / buy_price * 100

                        # 공통 손절 매도 주문
                        if 수익률 <= self.vLoss:
                            print("손절 매도 주문,수익률:%s"%수익률)
                            self.ORDER = False
                            Kiwoom.request_orderFO(self, "신규매도손절", oCode, 주문가능수량, "0",'손절','')

                        # 공통 이익 매도 주문
                        if 수익률 >= self.vProfit:
                            print("이익 매도 주문,수익률:%s"%수익률)
                            self.ORDER = False
                            Kiwoom.request_orderFO(self, "신규매도이익", oCode, 주문가능수량, "0", '이익','')

                # CORRECTION ORDER TERRITORY
                if S.correction_order_dict != {}:
                    cod = S.correction_order_dict
                    종목코드 = cod['종목코드']
                    미체결수량 = cod['미체결수량']

                    if oCode == 종목코드 and 미체결수량 > 0:
                        주문가격 = cod['주문가격']
                        가격차이 = round(e - 주문가격,3)
                        if S.정정 == False and e > 가격차이:
                            S.정정 = True
                            주문번호 = cod['주문번호']
                            Kiwoom.request_orderFO(self,'정정',종목코드,미체결수량,e,'',주문번호)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    main = MainWindow()
    sys.exit(app.exec_())