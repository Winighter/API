import os, pyotp
from hashlib import sha256
import hashlib

Block = []

class SecurityManager:
    def __init__(self):
        print('Run Security Manager')
        # self.add_block(data='data')

    def create_hash(data:str,prevHash:bytes) -> bytes:
        return sha256(data.encode() + prevHash).hexdigest()

    def add_block(self,data:str):
        current_hash = SecurityManager.create_hash('First Data',b'')
        Block.append((data,b''.decode(),current_hash))

        for i in range(100):
            _,_,prev_hash = Block[-1]
            prev_hash = bytes(prev_hash,'utf-8')
            current_hash = SecurityManager.create_hash(data,prev_hash)
            Block.append((data,prev_hash.decode(),current_hash))
            print(f'\n블록 {i}  {data}  {prev_hash.decode()}  {current_hash}')


    def get_otpCode(self):
        otp_value = pyotp.TOTP(pyotp.random_base32()).now()
        otp_value = otp_value[0:3]+'-'+otp_value[3:]
        return otp_value
    
    def vaccine(self):
        fp = open('eicar.txt','rb')
        fbuf = fp.read()
        fp.close()

        f = hashlib.md5()
        f.update(fbuf)
        hashValue = f.hexdigest()

        if hashValue == '44d88612fea8a8f36de82e1278abb02f':
            print("악성코드 발견!")
            os.chmod('eicar.txt')
            os.remove('eicar.txt')
        else:
            print("악성코드 없음")

    # malware = {
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    #     'name':'hashvalue',
    # }

if __name__ == '__main__':
    SecurityManager()
        