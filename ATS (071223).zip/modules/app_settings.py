class S(): # S = Settings
    # APP SETTINGS
    # ///////////////////////////////////////////////////////////////
    LOGIN_STATE = 0
    ORDER = False
    fCode = ''

    # DICTIONARY
    # ///////////////////////////////////////////////////////////////
    correction_order_dict = {}
    option_table_dict = {}
    balance_dict = {}
    # CONDITION
    # ///////////////////////////////////////////////////////////////
    Act_Check = 0
    매수 = False
    정정 = False
    손절Cnt = 0

    # 손익율 = (평가금액 - 약정금액)/약정금액*100 -0.03%