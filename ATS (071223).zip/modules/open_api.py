from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QAxContainer import *
from PyQt5.QtCore import *
from PyQt5.QtMultimedia import *
from PyQt5.QtMultimediaWidgets import *


from modules import *

class Kiwoom(QAxWidget):
    def __init__(self):
        pass

    def onLogin(self):
        if S.LOGIN_STATE == 0:
            Kiwoom.login_event_loop = QEventLoop()
            self.kiwoom = QAxWidget("KHOPENAPI.KHOpenAPICtrl.1")
            Kiwoom.onEvent(self)
            self.kiwoom.dynamicCall("CommConnect()")
            AppFunctions.loginState(self,2)
            Kiwoom.login_event_loop.exec_()
        else:
            Kiwoom.toggle_RealData_state(self, True)


    def onEvent(self):
        self.kiwoom.OnEventConnect.connect(self.login_slot)
        self.kiwoom.OnReceiveTrData.connect(self.trdata_slot)
        self.kiwoom.OnReceiveChejanData.connect(self.chejan_slot)
        self.kiwoom.OnReceiveRealData.connect(self.realdata_slot)

    def connect_real_data(self):
        if S.LOGIN_STATE == 1:
            Kiwoom.Disconnect_All_Real(self)
            Kiwoom.regist_Real_Code(self,'3692',S.fCode,'10','0')
            Kiwoom.regist_Real_Code(self,'3691',S.fCode,'128','1')
            Kiwoom.regist_Real_Code(self,'2000',self.cStr,'10;16;17;18','1')
            Kiwoom.regist_Real_Code(self,'2001',self.pStr,'10;16;17;18','1')
        else:
            QMessageBox.information(self,'로그인 오류','로그인이 되어 있지 않습니다.')

    def Disconnect_All_Real(self):
        if S.LOGIN_STATE == 1:
            self.kiwoom.dynamicCall("SetRealRemove(QString,QString)",'ALL','ALL')

    def regist_Real_Code(self,strScreenNo,CodeList,FidList,OptType):
        self.kiwoom.dynamicCall("SetRealReg(QString,QString,QString,QString)",strScreenNo,CodeList,FidList,OptType)

    def request_login_info(self):
        self.account = self.kiwoom.dynamicCall("GetLoginInfo(QString)","ACCOUNT_CNT")
        self.Number = self.kiwoom.dynamicCall("GetLoginInfo(QString)","ACCLIST")[:-1] # or "ACCNO" / 계좌번호
        user = self.kiwoom.dynamicCall("GetLoginInfo(QString)","USER_NAME") # 사용자 이름
        fList = self.kiwoom.dynamicCall("GetFutureList()").split(';')
        S.fCode = fList[0]

        fMonth = list(map(int, self.kiwoom.dynamicCall("GetMonthList()").split(';')))
        fMonth.sort()
        self.fMonth = str(fMonth[0])

        oMonth = list(map(int, self.kiwoom.dynamicCall("GetMonthList()").split(';')))
        oMonth.sort()
        self.oMonth = str(oMonth[0])
        self.request = False

    # Post here your functions for Tr Data
    # ///////////////////////////////////////////////////////////////
    def request_option_price(self):
        self.kiwoom.dynamicCall("SetInputValue(QString,QString)","만기년월",self.oMonth)
        self.kiwoom.dynamicCall("CommRqData(QString,QString,QString,QString)","옵션시세조회","opt50020","0", '1003')
        self.tr_event_loop.exec_()

    # ORDER FUNTION & ORDER RESULTS
    def request_orderFO(self,sRQName,sCode,lQty,sPrice,why,OrdNo):
        global order_err
        if sRQName == '신규매수':
            order_err = self.kiwoom.dynamicCall("SendOrderFO(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)",[
                sRQName,'1000',self.Number,sCode,'1','2','1',self.vQuantity,sPrice,''])

        if sRQName == ('신규매도손절' or '신규매도이익'):
            order_err = self.kiwoom.dynamicCall("SendOrderFO(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)",[
                sRQName,'1000',self.Number,sCode,'1','1','3',lQty,'3',''])

        if sRQName == '정정':
            order_err = self.kiwoom.dynamicCall("SendOrderFO(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)",[
                sRQName,'1000',self.Number,sCode,'2','2','1',lQty,sPrice,OrdNo])

        if order_err == 0:
            if sRQName == '신규매수':
                pass

            if sRQName == ('신규매도손절' or '신규매도이익'):
                S.balance_dict = {}
                S.매수 = False
                self.ORDER = True
                if sRQName == '신규매도손절':
                    S.손절Cnt += 1
                    if S.손절Cnt >= 2:
                        self.ORDER = False

            if sRQName == '신규매도이익':
                self.ORDER = False

            if sRQName == '정정':
                S.정정 = False