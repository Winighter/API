madict = {
    '':0
}